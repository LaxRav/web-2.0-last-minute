function login() {
    var credentials = {
        Name: $("#Name").val(),
        password: $("#password").val()
    }
    $.ajax({
        url:"/login",
        method:"post",
        data:credentials
    })
    .done(function(data) {
        $(".statusMessage").text(data.message);
        sessionStorage.authToken=data.token;
    })
    .fail(function(err){
        $(".statusMessage").text(err.responseText);
    })
    return false;
}

function register() {
    var newUser = {
       name: $("#Name").val(),
       email: $("#email").val(),
       Phonenumber: $("#number").val(),
       Address: $("#address").val(),
       Password: $("#password").val(),
       confirmpassword: $("#password").val()
    }
    $.ajax({
        url:"/register",
        method:"post",
        data: newRegister
    })
    .done(function(data){
        $(".statusMessage").text(data);
    })
    .fail(function (err){
        $(".statusMessage").text(err);
    })
    return false;
}