var mongoose = require('mongoose');
var schema = mongoose.Schema;
var registerSchema = {};
var registerModel;
var loginSchema = {};
var loginModel;

mongoose.set('useNewUrlParser', true);
mongoose.set('useFindAndModify', false);
mongoose.set('useCreateIndex', true);
mongoose.set('useUnifiedTopology', true);

mongoose.set('debug',true); 

var database = {
    connect: function() {
        mongoose.connect('mongodb://localhost:27017/userdb', function(err){
            if(err==null) {
                console.log("Connected to Mongo DB");
                //initialize values
               registerSchema = schema({
                   name: String,
                   email: String,
                   phone: Number,
                   Address: String,
                   password:String,
                   repassword: String
               }),
               loginSchema = schema({
                   name: String, 
                   password: String
               });
               var connection = mongoose.connection;
               registerModel = connection.model('register', registerSchema);
               loginModel = connection.model('login', loginSchema);
            } else {
                console.log("Error connecting to Mongo DB");
            }
        })
    },
    addUser: function(n, e, p, a, p, r, callback) {
        var newUser = new registerModel({
            name: n,
            email: e,
            phone: p,
            Address: a,
            password: p,
            repassword: r
        });
        newUser.save(callback);
    },
    newLogin: function(n, e, p, p, callback) {
        var newLogin = new loginModel({
            name: n,
            email: e,
            phone: p,
            password: p
        });
        newLogin.save(callback);
    },
    getUser: function(callback) {
        registerModel.findById(id).populate(callback);
    },

    getuserById: function(id, callback) {
        loginModel.findById(id,callback);
    },
    updateUser: function(id, n, d, sd, st, ed, et,callback) {
        var updatedUser = {
            name: n,
            description: d,
            start: {
                date: sd,
                time: st
            },
            end: {
                date: ed,
                time: et
            }
        };
        loginModel.findByIdAndUpdate(id, updatedEvent, callback);
    },
    deleteUser: function(id,callback) {
        registerModel.findByIdAndDelete(id,callback);
    }
};
module.exports = database;