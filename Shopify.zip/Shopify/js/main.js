console.log("running");

//get all add to cart  hover buttons do a document.queryAll('(class name)')
let carts = document.querySelectorAll('.add-cart');

let products = [
{
    name: 'Monster hunter apparel',
    tag: 'Monster hunter shirt',
    price:9.50,
    inCart:1
},
{
  name: 'Bape apparel',
  tag: 'Bape T-shirt',
  price:12.50,
  inCart:2
},
{
  name: 'Playstation Ps4 pro bundle',
  tag: 'ps4 pro',
  price:10.50,
  inCart:3
},
{
  name: 'Smartwatch collection',
  tag: 'smart watch',
  price:18.00,
  inCart:4
},
{
  name: 'Stranger things sweatshirt',
  tag: 'stranger things',
  price:24.00,
  inCart:5
},
{
  name: '',
  tag: 'Monster hunter shirt',
  price:9.50,
  inCart:6
},
{
  name: 'Monster hunter apparel',
  tag: 'Monster hunter shirt',
  price:9.50,
  inCart:7
},
{
  name: 'Monster hunter apparel',
  tag: 'Monster hunter shirt',
  price:9.50,
  inCart:1
}
];

for(let i=0; i < carts.length; i++) {
   carts[i].addEventListener('click', () => {
       cartNumbers();
       totalCost(products[i]);
   })
}

function onLoadCartNumbers() {
  let productNumbers = localStorage.getItem('cartNumbers');

  if(productNumbers) {
    document.querySelector('.cart span').textContent = productNumbers;
  }
}

function cartNumbers() {
  console.log("The product is clicked is", products);
  let productNumbers = localStorage.getItem('cartNumbers');
  

  productNumbers = parseInt(productNumbers);

  if( productNumbers ) {
    localStorage.setItem('cartNumbers', productNumbers + 1);
    document.querySelector('.cart span').textContent = productNumbers + 1;
  } else {
      localStorage.setItem('cartNumbers', 1);
      document.querySelector('.cart span').textContent = 1;
  }

  setItems(product);


  function setItems(product) {
    let cartItems = localStorage.getItem('productsInCart');
    cartItems = JSON.parse(cartItems)
    console.log("Inside of SetItems function");
    console.log("My product is", product);

    if(cartItems != null) {

      if(cartItems[products.tag] == undefined) {
        cartItems = {
          ...cartItems,
          [products.tag]: products
        }
      }
      cartItems[product.tag].inCart += 1;
    } else {
      product.inCart = 1;
      cartItems = {
        [product.tag]: product
      }
    }

   
    }
    localStorage.setItem("productsInCart", JSON.stringify (cartItems));
  }

  function totalCost(product) {

    let cartCost = localStorage.getItem('totalCost');
    cartCost = parseInt(cartCost);
    console.log("My cartcost is", cartCost);
    console.log(typeof cartCost)

    if(cartCost != null) {
      localStorage.setItem('totalCost', cartCost + product.price);
    } else {
    localStorage.setItems("totalCost", product.price);
  }

}




onLoadCartNumbers();
