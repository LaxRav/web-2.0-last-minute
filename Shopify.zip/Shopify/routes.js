const bodyParser = require('body-parser');
const crypto = require('crypto');
var db = require('./database/dataservice');
const mongoose = require('mongoose')
const express = require('express')

db.connect();


var routes = function () {
    var router = require('express').Router();

    router.use(bodyParser.urlencoded({
        extended: true
    }));

    router.get('/', function (req, res){
    res.sendFile(__dirname + '/views/index.html');
    });

    router.get('/css/*', function(req, res)  {
        res.sendFile(__dirname+"/views/"+req.originalUrl);
    });
    
    router.get('/js/*', function(req, res)  {
        res.sendFile(__dirname+"/views/"+req.originalUrl);
    });

    router.get('/login', function(req, res) {
        res.sendFile(__dirname + "/views/login.html");
    });

    router.get('/register', function (req, res) {
        res.sendFile(__dirname + "/views/register.html");
    });

    router.post('/login', function (req, res) {
        var data = req.body;
        db.login(data.name, data.email, data.password, function (err, login) {
            if(err) {
                res.status(401).send("Login unsuccessful. Please try again later");
            } else {
                if (login == null) {
                    res.status(401).send("Login unsuccessful. Please try again later");
                } else {
                    var strToHash = login.name + Date.now();
                    var token = crypto.createHash('md5').update(strToHash).digest('hex');
                    db.updateToken(login._id, token, function (err, login) {
                 res.status(200).json({'message': 'Login successful.', 'token': token});
                    });
                }
            }
        })
    })
   
    router.get("/logout", function (req, res){
        var token = req.query.token;
        if (token == undefined) {
            res.status(401).send("No tokens are provided");
        } else {
            db.checkToken(token, function (err, login){
                if (err || login == null) {
                    res.status(401).send("Invalid token provided");
                } else {
                    db.updateToken(login.__id, "", function (err, login) {
                        res.status(200).send("Logout successfully")
                    });
                }
            })
        }
    })


const userroute = require('./database/dataservice')
const AuthRoute = require('./models/auth')


return router;
};

module.exports = routes();